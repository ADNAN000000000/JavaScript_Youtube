let score = null

// console.log(typeof score);
let variableInNumber = Number(score)
// console.log(typeof variableInNumber);
// console.log( variableInNumber);
console.log();

/*
"33" => 33
"33a" => NaN
null => 0
true => 1
false => 0

*/
