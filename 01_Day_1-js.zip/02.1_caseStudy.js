// let isLoggedIn = 1 //true

// let isLoggedIn = 0 //false

// let isLoggedIn = ""//false

// let isLoggedIn = "Adnan" //true
let isLoggedIn = "investigation study"
let booleanIsLoggedIn = Boolean(isLoggedIn)

console.log(booleanIsLoggedIn);
console.log(typeof booleanIsLoggedIn);


