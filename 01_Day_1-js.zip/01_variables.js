const accountId = 141414
let accountMail = "adnan@gmail.com"
var accountPassword = "123123"
accountCity ="Hyderabad"
let accountState;


 accountMail = "ad@gmail.com"
 accountPassword = "1223"
accountCity ="Bengalore"
// accountId = 123 // thsi is not allowed since we are using const so the values can't be changed
console.log(accountId)
console.table([accountId, accountMail, accountPassword, accountCity, accountState])